<?php
/**
 * Schema Validering
 * - JSON lint (klient-side via JS)
 * - Google Rich Results Test link
 * - AJAX preview: render tokens på en valgt side
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_ajax_ssm_validate_schema', 'ssm_ajax_validate_schema' );
function ssm_ajax_validate_schema() {
    check_ajax_referer( 'ssm_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- raw JSON intentionally stored, sanitized via json_decode check below
    $json_raw = isset( $_POST['schema_json'] ) ? wp_unslash( $_POST['schema_json'] ) : '';
    $post_id  = intval( $_POST['post_id'] ?? 0 );

    // Strip script tags
    $json_raw = preg_replace( '/<script[^>]*>/i', '', $json_raw );
    $json_raw = preg_replace( '/<\/script>/i',    '', $json_raw );
    $json_raw = trim( $json_raw );

    // Replace tokens if a post_id is given
    if ( $post_id ) {
        // Simulate being on that post
        $GLOBALS['_ssm_preview_post_id'] = $post_id;
        $json_raw = ssm_replace_tokens_for_post( $json_raw, $post_id );
    }

    // JSON lint
    $decoded = json_decode( $json_raw );
    if ( json_last_error() !== JSON_ERROR_NONE ) {
        wp_send_json_error( [
            'message' => 'Ugyldig JSON: ' . json_last_error_msg(),
            'json'    => $json_raw,
        ] );
    }

    // Re-encode pretty
    $pretty = json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

    // Build Google Rich Results Test URL
    $test_url = '';
    if ( $post_id ) {
        $permalink = get_permalink( $post_id );
        $test_url  = 'https://search.google.com/test/rich-results?url=' . urlencode( $permalink );
    }

    wp_send_json_success( [
        'json'     => $pretty,
        'test_url' => $test_url,
        'post_url' => $post_id ? get_permalink( $post_id ) : '',
    ] );
}

/**
 * Replace tokens for a specific post (used in preview/validate).
 */
function ssm_replace_tokens_for_post( $json, $post_id ) {
    $post = get_post( $post_id );
    if ( ! $post ) return $json;

    $title         = get_the_title( $post );
    $excerpt       = ! empty( $post->post_excerpt ) ? $post->post_excerpt : wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
    $plain_content = wp_trim_words( wp_strip_all_tags( $post->post_content ), 40 );
    $permalink     = get_permalink( $post_id );
    $feat_img      = get_the_post_thumbnail_url( $post_id, 'large' ) ?: '';
    $post_date     = get_post_time( 'c', false, $post );
    $post_mod      = get_post_modified_time( 'c', false, $post );
    $author        = get_the_author_meta( 'display_name', $post->post_author );
    $cats          = wp_get_post_categories( $post_id, [ 'fields' => 'all' ] );
    $cat_name      = ! empty( $cats ) ? $cats[0]->name : '';
    $site_name     = get_bloginfo( 'name' );
    $site_url      = get_bloginfo( 'url' );
    $logo_url      = ssm_get_logo_url();

    $map = [
        '{post_title}'         => ssm_json_escape( $title ),
        '{post_excerpt}'       => ssm_json_escape( $excerpt ),
        '{post_content_plain}' => ssm_json_escape( $plain_content ),
        '{permalink}'          => ssm_json_escape( $permalink ),
        '{featured_image_url}' => ssm_json_escape( $feat_img ),
        '{post_date}'          => ssm_json_escape( $post_date ),
        '{post_modified}'      => ssm_json_escape( $post_mod ),
        '{author_name}'        => ssm_json_escape( $author ),
        '{category_name}'      => ssm_json_escape( $cat_name ),
        '{site_name}'          => ssm_json_escape( $site_name ),
        '{site_url}'           => ssm_json_escape( $site_url ),
        '{logo_url}'           => ssm_json_escape( $logo_url ),
    ];

    $json = str_replace( array_keys( $map ), array_values( $map ), $json );

    // Custom field tokens
    $json = preg_replace_callback(
        '/\{cf_([a-zA-Z0-9_\-]+)\}/',
        function( $matches ) use ( $post_id ) {
            $field_key = $matches[1];
            if ( function_exists( 'get_field' ) ) {
                $val = get_field( $field_key, $post_id );
                if ( is_array( $val ) && isset( $val['url'] ) ) $val = $val['url'];
                if ( is_array( $val ) && empty( $val ) ) $val = '';
                if ( is_array( $val ) && isset( $val[0]['url'] ) ) $val = $val[0]['url'];
                if ( $val instanceof WP_Post ) $val = get_the_title( $val );
                if ( is_array( $val ) ) $val = ! empty( $val ) ? (string) reset( $val ) : '';
                if ( $val !== null && $val !== false ) return ssm_json_escape( (string) $val );
            }
            $val = get_post_meta( $post_id, $field_key, true );
            return ssm_json_escape( (string) $val );
        },
        $json
    );

    return $json;
}

add_action( 'wp_ajax_ssm_search_preview_posts', 'ssm_ajax_search_preview_posts' );
function ssm_ajax_search_preview_posts() {
    check_ajax_referer( 'ssm_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    $q = sanitize_text_field( wp_unslash( $_GET['q'] ?? '' ) );
    $posts = get_posts( [
        's'              => $q,
        'post_type'      => 'any',
        'post_status'    => 'publish',
        'posts_per_page' => 15,
    ] );

    wp_send_json_success( array_map( function( $p ) {
        return [ 'id' => $p->ID, 'title' => get_the_title( $p ), 'type' => $p->post_type ];
    }, $posts ) );
}
