<?php
/**
 * Frontend – output global scripts, per-side scripts og schema markup
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------------------------------------------------------------
   Global: <head>
--------------------------------------------------------------- */
add_action( 'wp_head', 'ssm_output_global_head', 1 );
function ssm_output_global_head() {
    $scripts = get_option( 'ssm_header_scripts', '' );
    if ( ! empty( trim( $scripts ) ) ) {
        echo "\n<!-- Script Manager: Global Head -->\n";
        echo $scripts; // phpcs:ignore WordPress.Security.EscapeOutput
        echo "\n<!-- /Script Manager -->\n";
    }
}

/* ---------------------------------------------------------------
   Global: body_open (after <body>)
--------------------------------------------------------------- */
add_action( 'wp_body_open', 'ssm_output_global_body', 1 );
// Fallback for themes that don't call wp_body_open
add_action( 'wp_head', 'ssm_output_global_body_fallback', 999 );
function ssm_output_global_body() {
    static $done = false;
    if ( $done ) return;
    $done = true;
    $scripts = get_option( 'ssm_body_scripts', '' );
    if ( ! empty( trim( $scripts ) ) ) {
        echo "\n<!-- Script Manager: Global Body -->\n";
        echo $scripts; // phpcs:ignore WordPress.Security.EscapeOutput
        echo "\n<!-- /Script Manager -->\n";
    }
}
function ssm_output_global_body_fallback() {
    // Only fire if theme never fired wp_body_open
    if ( ! did_action( 'wp_body_open' ) ) {
        ssm_output_global_body();
    }
}

/* ---------------------------------------------------------------
   Global: footer
--------------------------------------------------------------- */
add_action( 'wp_footer', 'ssm_output_global_footer', 1 );
function ssm_output_global_footer() {
    $scripts = get_option( 'ssm_footer_scripts', '' );
    if ( ! empty( trim( $scripts ) ) ) {
        echo "\n<!-- Script Manager: Global Footer -->\n";
        echo $scripts; // phpcs:ignore WordPress.Security.EscapeOutput
        echo "\n<!-- /Script Manager -->\n";
    }
}

/* ---------------------------------------------------------------
   Per-side: <head> script
--------------------------------------------------------------- */
add_action( 'wp_head', 'ssm_output_page_head_script', 5 );
function ssm_output_page_head_script() {
    if ( ! is_singular() ) return;
    $post_id = get_the_ID();
    $script  = get_post_meta( $post_id, '_ssm_head_script', true );
    if ( ! empty( trim( $script ) ) ) {
        echo "\n<!-- Script Manager: Side-specifik Head -->\n";
        echo $script; // phpcs:ignore WordPress.Security.EscapeOutput
        echo "\n<!-- /Script Manager -->\n";
    }
}

/* ---------------------------------------------------------------
   Schema markup via regler
--------------------------------------------------------------- */
add_action( 'wp_head', 'ssm_output_schema_markup', 6 );
function ssm_output_schema_markup() {
    $rules = get_option( 'ssm_schema_rules', [] );
    if ( empty( $rules ) ) return;

    foreach ( $rules as $rule ) {
        if ( empty( $rule['enabled'] ) ) continue;
        $raw = trim( $rule['schema_json'] ?? '' );
        if ( empty( $raw ) ) continue;

        if ( ssm_rule_matches_current_page( $rule ) ) {
            // Strip any <script> tags the user may have included — we always add our own
            $json = ssm_strip_script_tags( $raw );
            $json = ssm_replace_tokens( $json );

            echo "\n<script type=\"application/ld+json\">\n";
            echo $json; // phpcs:ignore WordPress.Security.EscapeOutput
            echo "\n</script>\n";
        }
    }
}

/**
 * Remove surrounding <script ...> and </script> tags if present.
 */
function ssm_strip_script_tags( $content ) {
    // Remove opening <script ...> tag (any attributes)
    $content = preg_replace( '/<script[^>]*>/i', '', $content );
    // Remove closing </script>
    $content = preg_replace( '/<\/script>/i', '', $content );
    return trim( $content );
}

/**
 * Check om den aktuelle side matcher en regel.
 * Bruger conditions.php til udvidede typer.
 */
function ssm_rule_matches_current_page( $rule ) {
    $type       = $rule['target_type'] ?? 'all';
    $target_ids = array_filter( array_map( 'intval', (array) ( $rule['target_ids'] ?? [] ) ) );

    // Prøv først extended conditions (conditions.php)
    $extended = ssm_check_extended_conditions( $rule );
    if ( $extended !== null ) {
        return $extended;
    }

    // Original matching for de basale typer
    if ( $type === 'all' ) {
        return true;
    }

    if ( $type === 'pages' && is_singular() ) {
        return in_array( get_the_ID(), $target_ids, true );
    }

    if ( $type === 'categories' && ( is_category() || is_singular() ) ) {
        if ( is_category() ) {
            return in_array( get_queried_object_id(), $target_ids, true );
        }
        $post_cats = wp_get_post_categories( get_the_ID(), [ 'fields' => 'ids' ] );
        return (bool) array_intersect( $post_cats, $target_ids );
    }

    if ( $type === 'tags' && ( is_tag() || is_singular() ) ) {
        if ( is_tag() ) {
            return in_array( get_queried_object_id(), $target_ids, true );
        }
        $post_tags = wp_get_post_tags( get_the_ID(), [ 'fields' => 'ids' ] );
        return (bool) array_intersect( $post_tags, $target_ids );
    }

    if ( $type === 'post_type' ) {
        $slugs     = (array) ( $rule['target_ids'] ?? [] );
        $all_slugs = [];
        foreach ( $slugs as $s ) {
            foreach ( explode( ',', $s ) as $slug ) {
                $slug = trim( $slug );
                if ( $slug !== '' ) $all_slugs[] = $slug;
            }
        }
        return in_array( get_post_type(), $all_slugs, true );
    }

    return false;
}

/**
 * Erstat dynamiske tokens med faktiske sidedata
 */
function ssm_replace_tokens( $json ) {
    if ( ! is_singular() && ! is_category() ) return $json;

    // Post-level tokens (fallback to empty string on non-singular)
    $post_id  = is_singular() ? get_the_ID() : 0;
    $post     = $post_id ? get_post( $post_id ) : null;

    $title        = $post    ? get_the_title( $post )    : get_queried_object()->name ?? '';
    $excerpt      = $post    ? ssm_get_excerpt( $post )  : '';
    $plain_content = $post   ? wp_trim_words( wp_strip_all_tags( $post->post_content ), 40 ) : '';
    $permalink    = $post_id ? get_permalink( $post_id ) : get_term_link( get_queried_object() );
    $feat_img     = $post_id ? ( get_the_post_thumbnail_url( $post_id, 'large' ) ?: '' ) : '';
    $post_date    = $post    ? get_post_time( 'c', false, $post )        : '';
    $post_mod     = $post    ? get_post_modified_time( 'c', false, $post ) : '';
    $author       = $post    ? get_the_author_meta( 'display_name', $post->post_author ) : '';
    $cat_name     = $post_id ? ssm_get_primary_category( $post_id )      : '';

    // Site-level tokens
    $site_name = get_bloginfo( 'name' );
    $site_url  = get_bloginfo( 'url' );
    $logo_url  = ssm_get_logo_url();

    $map = [
        '{post_title}'         => ssm_json_escape( $title ),
        '{post_excerpt}'       => ssm_json_escape( $excerpt ),
        '{post_content_plain}' => ssm_json_escape( $plain_content ),
        '{permalink}'          => ssm_json_escape( is_string( $permalink ) ? $permalink : '' ),
        '{featured_image_url}' => ssm_json_escape( $feat_img ),
        '{post_date}'          => ssm_json_escape( $post_date ),
        '{post_modified}'      => ssm_json_escape( $post_mod ),
        '{author_name}'        => ssm_json_escape( $author ),
        '{category_name}'      => ssm_json_escape( $cat_name ),
        '{site_name}'          => ssm_json_escape( $site_name ),
        '{site_url}'           => ssm_json_escape( $site_url ),
        '{logo_url}'           => ssm_json_escape( $logo_url ),
    ];

    $json = str_replace( array_keys( $map ), array_values( $map ), $json );

    // Custom field tokens: {cf_feltnavn} → get_post_meta( $post_id, 'feltnavn' )
    // Also supports ACF: if ACF is active, uses get_field() for richer field types
    if ( $post_id ) {
        $json = preg_replace_callback(
            '/\{cf_([a-zA-Z0-9_\-]+)\}/',
            function( $matches ) use ( $post_id ) {
                $field_key = $matches[1];
                // ACF support
                if ( function_exists( 'get_field' ) ) {
                    $val = get_field( $field_key, $post_id );
                    // ACF image field returns array — get URL
                    if ( is_array( $val ) && isset( $val['url'] ) ) {
                        $val = $val['url'];
                    }
                    // ACF image field returns empty array when no image set
                    if ( is_array( $val ) && empty( $val ) ) {
                        $val = '';
                    }
                    // ACF gallery returns array of image arrays — get first URL
                    if ( is_array( $val ) && isset( $val[0]['url'] ) ) {
                        $val = $val[0]['url'];
                    }
                    // ACF relationship/post object returns WP_Post — get title
                    if ( $val instanceof WP_Post ) {
                        $val = get_the_title( $val );
                    }
                    // Any remaining array — encode as JSON string or take first element
                    if ( is_array( $val ) ) {
                        $val = ! empty( $val ) ? (string) reset( $val ) : '';
                    }
                    if ( $val !== null && $val !== false ) {
                        return ssm_json_escape( (string) $val );
                    }
                }
                // Standard post meta fallback
                $val = get_post_meta( $post_id, $field_key, true );
                return ssm_json_escape( (string) $val );
            },
            $json
        );
    }

    return $json;
}

/* ---------------------------------------------------------------
   Helpers
--------------------------------------------------------------- */

function ssm_get_excerpt( $post ) {
    if ( ! empty( $post->post_excerpt ) ) return $post->post_excerpt;
    return wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
}

function ssm_get_primary_category( $post_id ) {
    $cats = wp_get_post_categories( $post_id, [ 'fields' => 'all' ] );
    if ( empty( $cats ) ) return '';
    // Yoast primary category support
    if ( class_exists( 'WPSEO_Primary_Term' ) ) {
        $primary_term = new WPSEO_Primary_Term( 'category', $post_id );
        $primary_id   = $primary_term->get_primary_term();
        if ( $primary_id ) {
            $term = get_term( $primary_id, 'category' );
            if ( $term && ! is_wp_error( $term ) ) return $term->name;
        }
    }
    return $cats[0]->name;
}

function ssm_get_logo_url() {
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    if ( $custom_logo_id ) {
        $logo = wp_get_attachment_image_url( $custom_logo_id, 'full' );
        if ( $logo ) return $logo;
    }
    return '';
}

/**
 * Escape a value for safe insertion inside a JSON string value.
 * Does NOT add surrounding quotes — the template is responsible for those.
 */
function ssm_json_escape( $value ) {
    // json_encode wraps in quotes — strip them
    $encoded = json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
    // Remove surrounding double quotes
    return substr( $encoded, 1, -1 );
}
