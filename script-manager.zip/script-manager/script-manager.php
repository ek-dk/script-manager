<?php
/**
 * Plugin Name: Script & Schema Manager
 * Plugin URI:  https://github.com/ek-dk/script-manager
 * Description: Indsæt header/body/footer scripts globalt, per side/indlæg, og tilføj dynamiske schema markup (Product, AggregateRating m.fl.) til valgte sider eller kategorier.
 * Version:     1.0.0
 * Author:      Emre Kandemir
 * License:     GPL-2.0+
 * Text Domain: script-manager
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SSM_VERSION',    '1.1.0' );
define( 'SSM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SSM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once SSM_PLUGIN_DIR . 'includes/global-settings.php';
require_once SSM_PLUGIN_DIR . 'includes/meta-boxes.php';
require_once SSM_PLUGIN_DIR . 'includes/conditions.php';
require_once SSM_PLUGIN_DIR . 'includes/schema-rules.php';
require_once SSM_PLUGIN_DIR . 'includes/breadcrumb.php';
require_once SSM_PLUGIN_DIR . 'includes/validation.php';
require_once SSM_PLUGIN_DIR . 'includes/frontend.php';
require_once SSM_PLUGIN_DIR . 'includes/admin-assets.php';
