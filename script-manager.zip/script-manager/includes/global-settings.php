<?php
/**
 * Global Settings – Header / Body / Footer scripts
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', 'ssm_add_admin_menu' );
function ssm_add_admin_menu() {
    add_menu_page(
        'Script & Schema Manager',
        'Script Manager',
        'manage_options',
        'script-manager',
        'ssm_global_settings_page',
        'dashicons-editor-code',
        80
    );
    add_submenu_page(
        'script-manager',
        'Globale Scripts',
        'Globale Scripts',
        'manage_options',
        'script-manager',
        'ssm_global_settings_page'
    );
    add_submenu_page(
        'script-manager',
        'Schema Regler',
        'Schema Regler',
        'manage_options',
        'ssm-schema-rules',
        'ssm_schema_rules_page'
    );
}

add_action( 'admin_init', 'ssm_register_global_settings' );
function ssm_register_global_settings() {
    register_setting( 'ssm_global_settings', 'ssm_header_scripts',       [ 'sanitize_callback' => 'ssm_sanitize_script' ] );
    register_setting( 'ssm_global_settings', 'ssm_body_scripts',         [ 'sanitize_callback' => 'ssm_sanitize_script' ] );
    register_setting( 'ssm_global_settings', 'ssm_footer_scripts',       [ 'sanitize_callback' => 'ssm_sanitize_script' ] );
    register_setting( 'ssm_global_settings', 'ssm_breadcrumb_enabled',   [ 'sanitize_callback' => 'absint' ] );
    register_setting( 'ssm_global_settings', 'ssm_breadcrumb_home_label',[ 'sanitize_callback' => 'sanitize_text_field' ] );
}

/**
 * Scripts gemmes rå — kun administratorer med unfiltered_html må gemme.
 * På single-site har alle admins unfiltered_html.
 * På multisite er det kun superadmins — dette beskytter netværks-instanser.
 */
function ssm_sanitize_script( $value ) {
    if ( ! current_user_can( 'unfiltered_html' ) ) {
        add_settings_error(
            'ssm_global_settings',
            'ssm_permission_denied',
            'Du har ikke tilladelse til at gemme scripts. Kræver unfiltered_html-rettighed.',
            'error'
        );
        // Return existing value unchanged
        return get_option( current_filter() === 'sanitize_option_ssm_header_scripts'
            ? 'ssm_header_scripts'
            : ( current_filter() === 'sanitize_option_ssm_body_scripts' ? 'ssm_body_scripts' : 'ssm_footer_scripts' )
        );
    }
    return wp_unslash( $value );
}

function ssm_global_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    ?>
    <div class="wrap ssm-wrap">
        <h1>
            <span class="dashicons dashicons-editor-code"></span>
            Script &amp; Schema Manager – Globale Scripts
        </h1>
        <p class="description">Scripts her indsættes på <strong>alle sider</strong> på dit WordPress-site.</p>

        <form method="post" action="options.php">
            <?php settings_fields( 'ssm_global_settings' ); ?>

            <div class="ssm-card">
                <h2>
                    <span class="ssm-badge ssm-badge-head">&lt;head&gt;</span>
                    Header Scripts
                </h2>
                <p class="description">Placeres i <code>&lt;head&gt;</code>-sektionen. Brug til meta-tags, Google Tag Manager, stylesheets o.l.</p>
                <div class="ssm-editor-wrap">
                    <textarea id="ssm_header_scripts" name="ssm_header_scripts" class="ssm-code-editor" rows="8" spellcheck="false"><?php echo esc_textarea( get_option( 'ssm_header_scripts', '' ) ); ?></textarea>
                </div>
            </div>

            <div class="ssm-card">
                <h2>
                    <span class="ssm-badge ssm-badge-body">&lt;body&gt;</span>
                    Body Scripts
                </h2>
                <p class="description">Placeres lige efter det åbne <code>&lt;body&gt;</code>-tag. Brug til Google Tag Manager noscript o.l.</p>
                <div class="ssm-editor-wrap">
                    <textarea id="ssm_body_scripts" name="ssm_body_scripts" class="ssm-code-editor" rows="8" spellcheck="false"><?php echo esc_textarea( get_option( 'ssm_body_scripts', '' ) ); ?></textarea>
                </div>
            </div>

            <div class="ssm-card">
                <h2>
                    <span class="ssm-badge ssm-badge-footer">&lt;/body&gt;</span>
                    Footer Scripts
                </h2>
                <p class="description">Placeres før det lukkende <code>&lt;/body&gt;</code>-tag. Brug til analytics, chat-widgets o.l.</p>
                <div class="ssm-editor-wrap">
                    <textarea id="ssm_footer_scripts" name="ssm_footer_scripts" class="ssm-code-editor" rows="8" spellcheck="false"><?php echo esc_textarea( get_option( 'ssm_footer_scripts', '' ) ); ?></textarea>
                </div>
            </div>

            <?php submit_button( 'Gem ændringer', 'primary large' ); ?>

            <div class="ssm-card">
                <h2>
                    <span class="ssm-badge ssm-badge-schema">BreadcrumbList</span>
                    Automatisk Breadcrumb Schema
                </h2>
                <p class="description">
                    Genererer automatisk <code>BreadcrumbList</code> JSON-LD schema på alle sider.
                    Understøtter Yoast breadcrumbs hvis aktiveret — ellers bygges brødkrummen automatisk fra sidestrukturen.
                </p>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Aktivér breadcrumb schema</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ssm_breadcrumb_enabled" value="1" <?php checked( get_option( 'ssm_breadcrumb_enabled' ), 1 ); ?>>
                                Indsæt BreadcrumbList schema automatisk på alle sider
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ssm_breadcrumb_home_label">Hjemmeside-label</label></th>
                        <td>
                            <input type="text" id="ssm_breadcrumb_home_label" name="ssm_breadcrumb_home_label"
                                   value="<?php echo esc_attr( get_option( 'ssm_breadcrumb_home_label', '' ) ); ?>"
                                   placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
                                   class="regular-text">
                            <p class="description">Navn på første element i brødkrummen. Standard: sitets navn.</p>
                        </td>
                    </tr>
                </table>
            </div>

        </form>
    </div>
    <?php
}
