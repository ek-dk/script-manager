<?php
/**
 * Betinget logik & Taxonomy support
 * Håndterer matching for: custom taxonomies, template conditions
 * (forside, søgning, 404, arkiver, dato-arkiver osv.)
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Returnerer alle custom taxonomies på sitet (offentlige, ekskl. category og post_tag)
 */
function ssm_get_custom_taxonomies() {
    $all = get_taxonomies( [ 'public' => true ], 'objects' );
    unset( $all['category'], $all['post_tag'], $all['post_format'] );
    return $all;
}

/**
 * Liste over tilgængelige betingede logik-typer
 */
function ssm_get_condition_types() {
    return [
        // Generelle
        'all'           => [ 'label' => 'Hele sitet',                   'group' => 'Generelt' ],
        'front_page'    => [ 'label' => 'Forsiden',                      'group' => 'Generelt' ],
        'blog_index'    => [ 'label' => 'Blog-indeks (posts page)',       'group' => 'Generelt' ],
        'search'        => [ 'label' => 'Søgeresultater',                'group' => 'Generelt' ],
        'not_found'     => [ 'label' => '404-side',                      'group' => 'Generelt' ],
        // Indhold
        'pages'         => [ 'label' => 'Specifikke sider/indlæg',       'group' => 'Indhold' ],
        'post_type'     => [ 'label' => 'Post type (alle af typen)',      'group' => 'Indhold' ],
        // Taxonomies
        'categories'    => [ 'label' => 'Kategori-arkiv eller indlæg i kategori', 'group' => 'Taxonomy' ],
        'tags'          => [ 'label' => 'Tag-arkiv eller indlæg med tag', 'group' => 'Taxonomy' ],
        'custom_tax'    => [ 'label' => 'Custom taxonomy (vælg nedenfor)', 'group' => 'Taxonomy' ],
        // Arkiver
        'date_archive'  => [ 'label' => 'Dato-arkiv (år/måned/dag)',     'group' => 'Arkiver' ],
        'author_archive'=> [ 'label' => 'Forfatter-arkiv',               'group' => 'Arkiver' ],
        'any_archive'   => [ 'label' => 'Alle arkivsider',               'group' => 'Arkiver' ],
    ];
}

/**
 * Udvid ssm_rule_matches_current_page med de nye condition types.
 * Kaldes fra frontend.php – tilføjer support for de nye typer.
 */
function ssm_check_extended_conditions( $rule ) {
    $type       = $rule['target_type'] ?? 'all';
    $target_ids = (array) ( $rule['target_ids'] ?? [] );

    switch ( $type ) {
        case 'front_page':
            return is_front_page();

        case 'blog_index':
            return is_home();

        case 'search':
            return is_search();

        case 'not_found':
            return is_404();

        case 'date_archive':
            return is_date();

        case 'author_archive':
            return is_author();

        case 'any_archive':
            return is_archive();

        case 'custom_tax':
            // target_ids = [ 'taxonomy_slug', term_id, term_id, ... ]
            // Format stored: first element = taxonomy slug, rest = term IDs
            if ( empty( $target_ids ) ) return false;
            $tax_slug = sanitize_key( array_shift( $target_ids ) );
            $term_ids = array_map( 'intval', $target_ids );

            if ( empty( $term_ids ) ) {
                // No specific terms — match any page that uses this taxonomy
                if ( is_tax( $tax_slug ) ) return true;
                if ( is_singular() ) {
                    $terms = wp_get_object_terms( get_the_ID(), $tax_slug, [ 'fields' => 'ids' ] );
                    return ! empty( $terms ) && ! is_wp_error( $terms );
                }
                return false;
            }

            if ( is_tax( $tax_slug ) ) {
                return in_array( get_queried_object_id(), $term_ids, true );
            }
            if ( is_singular() ) {
                $post_terms = wp_get_object_terms( get_the_ID(), $tax_slug, [ 'fields' => 'ids' ] );
                if ( is_wp_error( $post_terms ) ) return false;
                return (bool) array_intersect( $post_terms, $term_ids );
            }
            return false;

        default:
            return null; // Signal: ikke håndteret her, brug original matching
    }
}
