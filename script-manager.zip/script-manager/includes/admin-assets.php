<?php
/**
 * Admin assets – CSS + JS til plugin-siderne
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_enqueue_scripts', 'ssm_enqueue_admin_assets' );
function ssm_enqueue_admin_assets( $hook ) {
    $ssm_pages = [ 'toplevel_page_script-manager', 'script-manager_page_ssm-schema-rules' ];
    $is_ssm_page = in_array( $hook, $ssm_pages, true );

    // Also load on post/page edit screens for meta box
    $is_edit_screen = in_array( $hook, [ 'post.php', 'post-new.php' ], true );

    if ( ! $is_ssm_page && ! $is_edit_screen ) return;

    wp_enqueue_style(
        'ssm-admin',
        SSM_PLUGIN_URL . 'assets/css/admin.css',
        [],
        SSM_VERSION
    );

    if ( $is_ssm_page ) {
        wp_enqueue_script(
            'ssm-admin',
            SSM_PLUGIN_URL . 'assets/js/admin.js',
            [ 'jquery' ],
            SSM_VERSION,
            true
        );

        wp_localize_script( 'ssm-admin', 'ssmData', [
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'ssm_ajax' ),
        ] );

        // Post types for dynamic rule cards
        $pt_objects = get_post_types( [ 'public' => true ], 'objects' );
        $pt_list    = array_values( array_map( function( $pt ) {
            return [ 'slug' => $pt->name, 'label' => $pt->label ];
        }, $pt_objects ) );

        $cat_list = array_values( array_map( function( $cat ) {
            return [ 'id' => $cat->term_id, 'name' => $cat->name ];
        }, get_categories( [ 'hide_empty' => false ] ) ) );

        $tag_list = array_values( array_map( function( $tag ) {
            return [ 'id' => $tag->term_id, 'name' => $tag->name ];
        }, get_tags( [ 'hide_empty' => false ] ) ) );

        $custom_tax_list = array_values( array_map( function( $tx ) {
            return [ 'slug' => $tx->name, 'label' => $tx->label ];
        }, ssm_get_custom_taxonomies() ) );

        wp_add_inline_script( 'ssm-admin',
            'var ssmPostTypes = '        . wp_json_encode( $pt_list ) . ';' .
            'var ssmCategories = '       . wp_json_encode( $cat_list ) . ';' .
            'var ssmTags = '             . wp_json_encode( $tag_list ) . ';' .
            'var ssmCustomTaxonomies = ' . wp_json_encode( $custom_tax_list ) . ';'
        );
    }
}

/* ---------------------------------------------------------------
   AJAX: page search for ID lookup
--------------------------------------------------------------- */
add_action( 'wp_ajax_ssm_get_tax_terms', 'ssm_ajax_get_tax_terms' );
add_action( 'wp_ajax_ssm_search_posts',  'ssm_ajax_search_posts' );
add_action( 'wp_ajax_ssm_validate_schema', 'ssm_ajax_validate_schema' );
function ssm_ajax_get_tax_terms() {
    check_ajax_referer( 'ssm_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    $tax = sanitize_key( $_GET['tax'] ?? '' );
    if ( ! taxonomy_exists( $tax ) ) wp_send_json_error();

    $terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => false, 'orderby' => 'name' ] );
    if ( is_wp_error( $terms ) ) wp_send_json_error();

    wp_send_json_success( array_map( function( $t ) {
        return [ 'id' => $t->term_id, 'name' => $t->name, 'count' => $t->count ];
    }, $terms ) );
}
function ssm_ajax_search_posts() {
    check_ajax_referer( 'ssm_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    $search = sanitize_text_field( $_GET['q'] ?? '' );
    $posts  = get_posts( [
        's'              => $search,
        'post_type'      => 'any',
        'post_status'    => 'publish',
        'posts_per_page' => 20,
        'orderby'        => 'relevance',
    ] );

    $results = array_map( function( $p ) {
        return [
            'id'    => $p->ID,
            'title' => get_the_title( $p ),
            'type'  => $p->post_type,
            'url'   => get_permalink( $p ),
        ];
    }, $posts );

    wp_send_json_success( $results );
}
