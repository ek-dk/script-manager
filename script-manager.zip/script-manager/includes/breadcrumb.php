<?php
/**
 * BreadcrumbList Schema – automatisk genereret JSON-LD
 * Aktiveres via en global indstilling i Script Manager settings.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_init', 'ssm_register_breadcrumb_setting' );
function ssm_register_breadcrumb_setting() {
    register_setting( 'ssm_global_settings', 'ssm_breadcrumb_enabled', [ 'sanitize_callback' => 'absint' ] );
    register_setting( 'ssm_global_settings', 'ssm_breadcrumb_home_label', [ 'sanitize_callback' => 'sanitize_text_field' ] );
}

add_action( 'wp_head', 'ssm_output_breadcrumb_schema', 7 );
function ssm_output_breadcrumb_schema() {
    if ( ! get_option( 'ssm_breadcrumb_enabled' ) ) return;

    $items = ssm_build_breadcrumb_items();
    if ( count( $items ) < 2 ) return; // Ingen breadcrumb på forsiden alene

    $list_items = [];
    foreach ( $items as $pos => $item ) {
        $list_items[] = [
            '@type'    => 'ListItem',
            'position' => $pos + 1,
            'name'     => $item['name'],
            'item'     => $item['url'],
        ];
    }

    $schema = [
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $list_items,
    ];

    echo "\n<script type=\"application/ld+json\">\n";
    echo wp_json_encode( $schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
    echo "\n</script>\n";
}

/**
 * Byg breadcrumb-elementer baseret på den aktuelle side.
 * Understøtter: singular, category, tag, custom taxonomy, author, date, search, 404.
 * Bruger Yoast breadcrumbs hvis tilgængeligt — ellers bygger vi selv.
 */
function ssm_build_breadcrumb_items() {
    $home_label = get_option( 'ssm_breadcrumb_home_label', '' ) ?: get_bloginfo( 'name' );
    $home_url   = home_url( '/' );

    $items = [ [ 'name' => $home_label, 'url' => $home_url ] ];

    // Yoast breadcrumb integration
    if ( function_exists( 'yoast_breadcrumb' ) && class_exists( 'WPSEO_Breadcrumbs' ) ) {
        return ssm_breadcrumbs_from_yoast( $items );
    }

    // Fallback: byg selv
    if ( is_front_page() ) {
        return []; // Ingen breadcrumb på forsiden
    }

    if ( is_singular() ) {
        $post = get_queried_object();

        // Kategori-sti (posts)
        if ( $post->post_type === 'post' ) {
            $cats = get_the_category( $post->ID );
            if ( $cats ) {
                // Find parent chain for primær kategori
                $cat   = $cats[0];
                $chain = ssm_get_term_ancestors( $cat, 'category' );
                foreach ( $chain as $ancestor ) {
                    $items[] = [ 'name' => $ancestor->name, 'url' => get_term_link( $ancestor ) ];
                }
            }
        }

        // Custom post type: tilføj evt. archive-link
        if ( $post->post_type !== 'post' && $post->post_type !== 'page' ) {
            $pt_obj = get_post_type_object( $post->post_type );
            if ( $pt_obj && $pt_obj->has_archive ) {
                $items[] = [ 'name' => $pt_obj->label, 'url' => get_post_type_archive_link( $post->post_type ) ];
            }
        }

        // Forældre-sider (pages)
        if ( $post->post_type === 'page' && $post->post_parent ) {
            $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
            foreach ( $ancestors as $ancestor_id ) {
                $items[] = [ 'name' => get_the_title( $ancestor_id ), 'url' => get_permalink( $ancestor_id ) ];
            }
        }

        $items[] = [ 'name' => get_the_title( $post ), 'url' => get_permalink( $post ) ];
        return $items;
    }

    if ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term->parent ) {
            $chain = ssm_get_term_ancestors( $term, $term->taxonomy );
            foreach ( $chain as $ancestor ) {
                $items[] = [ 'name' => $ancestor->name, 'url' => get_term_link( $ancestor ) ];
            }
        }
        $items[] = [ 'name' => $term->name, 'url' => get_term_link( $term ) ];
        return $items;
    }

    if ( is_author() ) {
        $items[] = [ 'name' => get_the_author_meta( 'display_name', get_queried_object_id() ), 'url' => get_author_posts_url( get_queried_object_id() ) ];
        return $items;
    }

    if ( is_search() ) {
        $items[] = [ 'name' => 'Søgeresultater: ' . get_search_query(), 'url' => get_search_link() ];
        return $items;
    }

    if ( is_404() ) {
        $items[] = [ 'name' => 'Side ikke fundet', 'url' => '' ];
        return $items;
    }

    if ( is_date() ) {
        $items[] = [ 'name' => get_the_date( 'F Y' ), 'url' => get_month_link( get_query_var( 'year' ), get_query_var( 'monthnum' ) ) ];
        return $items;
    }

    return $items;
}

function ssm_get_term_ancestors( $term, $taxonomy ) {
    $ancestors = [];
    $parent_id = $term->parent;
    while ( $parent_id ) {
        $parent    = get_term( $parent_id, $taxonomy );
        if ( ! $parent || is_wp_error( $parent ) ) break;
        array_unshift( $ancestors, $parent );
        $parent_id = $parent->parent;
    }
    return $ancestors;
}

function ssm_breadcrumbs_from_yoast( $fallback ) {
    // Hent Yoast breadcrumb data via intern metode
    try {
        $crumbs = WPSEO_Breadcrumbs::get_links();
        if ( empty( $crumbs ) ) return $fallback;
        $items = [];
        foreach ( $crumbs as $crumb ) {
            $items[] = [
                'name' => $crumb['text'] ?? '',
                'url'  => $crumb['url']  ?? '',
            ];
        }
        return $items;
    } catch ( Exception $e ) {
        return $fallback;
    }
}
