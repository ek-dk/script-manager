<?php
/**
 * Schema Rules – dynamisk JSON-LD schema markup
 * Understøtter Product, AggregateRating, LocalBusiness m.fl.
 * med dynamiske parametre trukket fra siden.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------------------------------------------------------------
   Helpers
--------------------------------------------------------------- */

function ssm_get_schema_rules() {
    return get_option( 'ssm_schema_rules', [] );
}

function ssm_save_schema_rules( $rules ) {
    update_option( 'ssm_schema_rules', $rules );
}

/**
 * Tilgængelige dynamiske tokens med forklaring
 */
function ssm_get_tokens() {
    return [
        '{post_title}'          => 'Sidens titel (post title)',
        '{post_excerpt}'        => 'Sidens uddrag / excerpt',
        '{post_content_plain}'  => 'Sidens indhold (plain text, afkortet)',
        '{site_name}'           => 'Sitets navn (blogname)',
        '{site_url}'            => 'Sitets URL',
        '{permalink}'           => 'Sidens fulde URL',
        '{featured_image_url}'  => 'URL på fremhævet billede',
        '{logo_url}'            => 'URL på site-logo (custom logo)',
        '{post_date}'           => 'Publiceringsdato (ISO 8601)',
        '{post_modified}'       => 'Senest ændret dato (ISO 8601)',
        '{author_name}'         => 'Forfatterens display-navn',
        '{category_name}'       => 'Primær kategori',
        '{cf_FELTNAVN}'         => 'Custom field / ACF felt — erstat FELTNAVN med feltets nøgle (fx {cf_pris}, {cf_by}, {cf_rating})',
    ];
}

/**
 * Hent unikke custom field keys fra sitet (til admin-reference)
 * Ekskluderer WP-interne og Yoast-felter
 */
function ssm_get_site_custom_fields() {
    global $wpdb;
    $excluded_prefixes = [ '_', 'yoast', 'rank_math', '_edit', '_encloseme', '_pingme', '_thumbnail' ];

    $keys = $wpdb->get_col(
        "SELECT DISTINCT meta_key FROM {$wpdb->postmeta}
         WHERE meta_key NOT LIKE '\_%'
         ORDER BY meta_key ASC
         LIMIT 200"
    );

    // Also check if ACF is active and get field groups
    $acf_fields = [];
    if ( function_exists( 'acf_get_field_groups' ) ) {
        $groups = acf_get_field_groups();
        foreach ( $groups as $group ) {
            $fields = acf_get_fields( $group['key'] );
            if ( $fields ) {
                foreach ( $fields as $field ) {
                    $acf_fields[ $field['name'] ] = $field['label'] . ' (' . $field['type'] . ')';
                }
            }
        }
    }

    return [
        'meta_keys'  => array_values( $keys ),
        'acf_fields' => $acf_fields,
    ];
}

/* ---------------------------------------------------------------
   Admin page
--------------------------------------------------------------- */

function ssm_schema_rules_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;

    // Handle save
    if ( isset( $_POST['ssm_schema_nonce'] ) && wp_verify_nonce( $_POST['ssm_schema_nonce'], 'ssm_save_schema_rules' ) ) {
        $rules = [];
        if ( ! empty( $_POST['ssm_rules'] ) && is_array( $_POST['ssm_rules'] ) ) {
            foreach ( $_POST['ssm_rules'] as $rule ) {
                $target_type = sanitize_key( $rule['target_type'] ?? 'all' );

                // Parse target_ids depending on type
                if ( $target_type === 'post_type' ) {
                    // Stored as array of slugs from multi-select
                    $raw_ids = isset( $rule['target_ids'] ) ? (array) $rule['target_ids'] : [];
                    $ids     = array_filter( array_map( 'sanitize_key', $raw_ids ) );
                } else {
                    // Stored as array of integers (page IDs or category term IDs)
                    $raw_ids = isset( $rule['target_ids'] ) ? (array) $rule['target_ids'] : [];
                    $ids     = array_filter( array_map( 'intval', $raw_ids ) );
                }

                $rules[] = [
                    'label'       => sanitize_text_field( wp_unslash( $rule['label'] ?? '' ) ),
                    'target_type' => $target_type,
                    'target_ids'  => array_values( $ids ),
                    'schema_json' => wp_unslash( $rule['schema_json'] ?? '' ),
                    'enabled'     => ! empty( $rule['enabled'] ),
                ];
            }
        }
        ssm_save_schema_rules( $rules );
        echo '<div class="notice notice-success is-dismissible"><p>Schema regler gemt!</p></div>';
    }

    // Handle delete
    if ( isset( $_GET['ssm_delete_rule'] ) && isset( $_GET['_wpnonce'] ) && wp_verify_nonce( $_GET['_wpnonce'], 'ssm_delete_rule' ) ) {
        $idx   = intval( $_GET['ssm_delete_rule'] );
        $rules = ssm_get_schema_rules();
        array_splice( $rules, $idx, 1 );
        ssm_save_schema_rules( $rules );
        wp_redirect( admin_url( 'admin.php?page=ssm-schema-rules&deleted=1' ) );
        exit;
    }

    $rules      = ssm_get_schema_rules();
    $tokens     = ssm_get_tokens();
    $categories = get_categories( [ 'hide_empty' => false ] );
    $condition_types   = ssm_get_condition_types();
    $custom_taxonomies = ssm_get_custom_taxonomies();

    // Schema type templates
    $schema_templates = [
        'product_aggregate' => json_encode( [
            "@context"        => "https://schema.org/",
            "@type"           => "Product",
            "name"            => "{post_title}",
            "image"           => "{featured_image_url}",
            "description"     => "{post_excerpt}",
            "brand"           => [ "@type" => "Brand", "name" => "{site_name}" ],
            "aggregateRating" => [
                "@type"       => "AggregateRating",
                "ratingValue" => "4.9",
                "bestRating"  => "5",
                "worstRating" => "1",
                "ratingCount" => "240",
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),

        'local_business' => json_encode( [
            "@context"    => "https://schema.org",
            "@type"       => "LocalBusiness",
            "name"        => "{post_title}",
            "url"         => "{permalink}",
            "image"       => "{featured_image_url}",
            "description" => "{post_excerpt}",
            "aggregateRating" => [
                "@type"       => "AggregateRating",
                "ratingValue" => "4.9",
                "bestRating"  => "5",
                "worstRating" => "1",
                "ratingCount" => "240",
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),

        'organization' => json_encode( [
            "@context" => "https://schema.org",
            "@type"    => "Organization",
            "name"     => "{site_name}",
            "url"      => "{site_url}",
            "logo"     => "{logo_url}",
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),

        'faq' => json_encode( [
            "@context"   => "https://schema.org",
            "@type"      => "FAQPage",
            "mainEntity" => [
                [ "@type" => "Question", "name" => "Spørgsmål 1?", "acceptedAnswer" => [ "@type" => "Answer", "text" => "Svar på spørgsmål 1." ] ],
                [ "@type" => "Question", "name" => "Spørgsmål 2?", "acceptedAnswer" => [ "@type" => "Answer", "text" => "Svar på spørgsmål 2." ] ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
    ];

    ?>
    <div class="wrap ssm-wrap">
        <h1>
            <span class="dashicons dashicons-editor-code"></span>
            Script &amp; Schema Manager – Schema Regler
        </h1>
        <p class="description">
            Opret regler der automatisk indsætter JSON-LD schema markup på udvalgte sider eller kategorier.
            Brug dynamiske tokens (se nedenfor) til at trække data fra siden.
        </p>

        <?php if ( isset( $_GET['deleted'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>Regel slettet.</p></div>
        <?php endif; ?>

        <!-- Token reference -->
        <div class="ssm-card ssm-token-card">
            <h3><span class="dashicons dashicons-info-outline"></span> Dynamiske tokens</h3>
            <p class="description">Disse tokens erstattes automatisk med sidedata, når schema'et renderes:</p>
            <div class="ssm-token-grid">
                <?php foreach ( $tokens as $token => $desc ) : ?>
                    <div class="ssm-token-item">
                        <code class="ssm-token-copy" title="Klik for at kopiere"><?php echo esc_html( $token ); ?></code>
                        <span><?php echo esc_html( $desc ); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php
            $cf_data = ssm_get_site_custom_fields();
            $has_acf = ! empty( $cf_data['acf_fields'] );
            $has_meta = ! empty( $cf_data['meta_keys'] );
            if ( $has_acf || $has_meta ) :
            ?>
            <div class="ssm-cf-section">
                <h4><span class="dashicons dashicons-admin-generic"></span> Custom fields på dette site</h4>

                <?php if ( $has_acf ) : ?>
                    <p class="description"><strong>ACF felter</strong> — klik for at kopiere token:</p>
                    <div class="ssm-token-grid">
                        <?php foreach ( $cf_data['acf_fields'] as $key => $label ) : ?>
                            <div class="ssm-token-item">
                                <code class="ssm-token-copy" title="Klik for at kopiere">{cf_<?php echo esc_html( $key ); ?>}</code>
                                <span><?php echo esc_html( $label ); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ( $has_meta && ! $has_acf ) : ?>
                    <p class="description"><strong>Post meta felter</strong> — klik for at kopiere token:</p>
                    <div class="ssm-cf-meta-list">
                        <?php foreach ( $cf_data['meta_keys'] as $key ) : ?>
                            <code class="ssm-token-copy ssm-cf-key" title="Klik for at kopiere">{cf_<?php echo esc_html( $key ); ?>}</code>
                        <?php endforeach; ?>
                    </div>
                <?php elseif ( $has_meta ) : ?>
                    <details style="margin-top:10px">
                        <summary class="description" style="cursor:pointer">Vis alle rå post meta-nøgler (<?php echo count( $cf_data['meta_keys'] ); ?>)</summary>
                        <div class="ssm-cf-meta-list" style="margin-top:8px">
                            <?php foreach ( $cf_data['meta_keys'] as $key ) : ?>
                                <code class="ssm-token-copy ssm-cf-key" title="Klik for at kopiere">{cf_<?php echo esc_html( $key ); ?>}</code>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <form method="post">
            <?php wp_nonce_field( 'ssm_save_schema_rules', 'ssm_schema_nonce' ); ?>

            <div id="ssm-rules-container">
                <?php foreach ( $rules as $i => $rule ) : ?>
                    <?php ssm_render_rule_card( $i, $rule, $categories, $custom_taxonomies ); ?>
                <?php endforeach; ?>
                <div id="ssm-rules-empty" style="<?php echo ! empty( $rules ) ? 'display:none' : ''; ?>">
                    <div class="ssm-card ssm-empty-state">
                        <span class="dashicons dashicons-plus-alt2" style="font-size:40px;color:#c3c4c7;display:block;text-align:center;margin-bottom:12px;"></span>
                        <p style="text-align:center;color:#666;">Ingen schema regler oprettet endnu. Klik "Tilføj ny regel" for at komme i gang.</p>
                    </div>
                </div>
            </div>

            <div class="ssm-actions-bar">
                <button type="button" id="ssm-add-rule" class="button button-secondary">
                    <span class="dashicons dashicons-plus-alt2"></span> Tilføj ny regel
                </button>
                <?php submit_button( 'Gem alle regler', 'primary large', 'submit', false ); ?>
            </div>
        </form>
    </div>

    <!-- Rule template (hidden) -->
    <script type="text/html" id="ssm-rule-template">
        <?php ssm_render_rule_card( '__IDX__', [
            'label'       => '',
            'target_type' => 'all',
            'target_ids'  => [],
            'schema_json' => '',
            'enabled'     => true,
        ], $categories, $custom_taxonomies, true ); ?>
    </script>

    <script>
    var ssmTemplates = <?php echo json_encode( $schema_templates ); ?>;
    var ssmConditionTypes = <?php echo json_encode( $condition_types ); ?>;
    </script>
    <?php
}

/**
 * Render a single rule card
 */
function ssm_render_rule_card( $i, $rule, $categories, $custom_taxonomies = [], $is_template = false ) {
    $target_type  = $rule['target_type'] ?? 'all';
    $target_ids   = $rule['target_ids']  ?? [];
    $tax_slug     = $rule['custom_tax_slug'] ?? '';
    $enabled      = $rule['enabled']     ?? true;
    $schema_json  = $rule['schema_json'] ?? '';
    $label        = $rule['label']       ?? '';
    $condition_types = ssm_get_condition_types();

    // Types that need a secondary selection panel
    $needs_ids = in_array( $target_type, [ 'pages', 'categories', 'tags', 'post_type', 'custom_tax' ] );
    ?>
    <div class="ssm-card ssm-rule-card" data-idx="<?php echo esc_attr( $i ); ?>">
        <div class="ssm-rule-header">
            <div class="ssm-rule-header-left">
                <span class="ssm-drag-handle dashicons dashicons-move"></span>
                <input
                    type="text"
                    name="ssm_rules[<?php echo esc_attr($i); ?>][label]"
                    value="<?php echo esc_attr( $label ); ?>"
                    placeholder="Regelens navn (fx 'Product schema – by-sider')"
                    class="ssm-rule-label-input"
                >
            </div>
            <div class="ssm-rule-header-right">
                <label class="ssm-toggle" title="Aktivér/deaktivér regel">
                    <input type="checkbox" name="ssm_rules[<?php echo esc_attr($i); ?>][enabled]" value="1" <?php checked( $enabled ); ?>>
                    <span class="ssm-toggle-slider"></span>
                </label>
                <?php if ( ! $is_template ) : ?>
                    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=ssm-schema-rules&ssm_delete_rule=' . $i ), 'ssm_delete_rule' ) ); ?>"
                       class="ssm-delete-rule button button-link-delete"
                       onclick="return confirm('Slet denne regel?')">
                        <span class="dashicons dashicons-trash"></span>
                    </a>
                <?php else: ?>
                    <button type="button" class="ssm-remove-rule button button-link-delete">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="ssm-rule-body">
            <div class="ssm-rule-row">
                <!-- Condition type -->
                <div class="ssm-rule-col">
                    <label><strong>Vis schema på</strong></label>
                    <select name="ssm_rules[<?php echo esc_attr($i); ?>][target_type]" class="ssm-target-type widefat">
                        <?php
                        $current_group = '';
                        foreach ( $condition_types as $val => $def ) :
                            if ( $def['group'] !== $current_group ) :
                                if ( $current_group !== '' ) echo '</optgroup>';
                                echo '<optgroup label="' . esc_attr( $def['group'] ) . '">';
                                $current_group = $def['group'];
                            endif;
                        ?>
                            <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $target_type, $val ); ?>>
                                <?php echo esc_html( $def['label'] ); ?>
                            </option>
                        <?php endforeach; ?>
                        </optgroup>
                    </select>
                </div>

                <!-- Secondary: target IDs / taxonomy -->
                <div class="ssm-rule-col ssm-target-ids-wrap" style="<?php echo ! $needs_ids ? 'display:none' : ''; ?>">
                    <?php if ( $target_type === 'categories' ) : ?>
                        <label><strong>Vælg kategorier</strong></label>
                        <select name="ssm_rules[<?php echo esc_attr($i); ?>][target_ids][]" class="ssm-ids-select widefat" multiple size="6">
                            <?php foreach ( $categories as $cat ) : ?>
                                <option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php echo in_array( $cat->term_id, $target_ids, false ) ? 'selected' : ''; ?>>
                                    <?php echo esc_html( $cat->name ); ?> (<?php echo esc_html( $cat->count ); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>

                    <?php elseif ( $target_type === 'tags' ) : ?>
                        <?php $all_tags = get_tags( [ 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ] ); ?>
                        <label><strong>Vælg tags</strong></label>
                        <select name="ssm_rules[<?php echo esc_attr($i); ?>][target_ids][]" class="ssm-ids-select widefat" multiple size="6">
                            <?php foreach ( $all_tags as $tag ) : ?>
                                <option value="<?php echo esc_attr( $tag->term_id ); ?>" <?php echo in_array( $tag->term_id, $target_ids, false ) ? 'selected' : ''; ?>>
                                    <?php echo esc_html( $tag->name ); ?> (<?php echo esc_html( $tag->count ); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>

                    <?php elseif ( $target_type === 'post_type' ) : ?>
                        <?php $all_post_types = get_post_types( [ 'public' => true ], 'objects' ); ?>
                        <label><strong>Vælg post typer</strong></label>
                        <select name="ssm_rules[<?php echo esc_attr($i); ?>][target_ids][]" class="ssm-ids-select widefat" multiple size="6">
                            <?php foreach ( $all_post_types as $pt ) : ?>
                                <option value="<?php echo esc_attr( $pt->name ); ?>" <?php echo in_array( $pt->name, $target_ids, true ) ? 'selected' : ''; ?>>
                                    <?php echo esc_html( $pt->label ); ?> (<?php echo esc_html( $pt->name ); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>

                    <?php elseif ( $target_type === 'custom_tax' ) : ?>
                        <label><strong>Taxonomy</strong></label>
                        <select name="ssm_rules[<?php echo esc_attr($i); ?>][custom_tax_slug]" class="ssm-custom-tax-select widefat">
                            <option value="">— Vælg taxonomy —</option>
                            <?php foreach ( $custom_taxonomies as $tx ) : ?>
                                <option value="<?php echo esc_attr( $tx->name ); ?>" <?php selected( $tax_slug, $tx->name ); ?>>
                                    <?php echo esc_html( $tx->label ); ?> (<?php echo esc_html( $tx->name ); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ( $tax_slug ) :
                            $tax_terms = get_terms( [ 'taxonomy' => $tax_slug, 'hide_empty' => false ] );
                            if ( ! is_wp_error( $tax_terms ) && ! empty( $tax_terms ) ) :
                        ?>
                        <label style="margin-top:10px;display:block"><strong>Vælg terms</strong> <small>(valgfrit — tom = alle terms)</small></label>
                        <select name="ssm_rules[<?php echo esc_attr($i); ?>][target_ids][]" class="ssm-ids-select widefat" multiple size="5">
                            <?php foreach ( $tax_terms as $term ) : ?>
                                <option value="<?php echo esc_attr( $term->term_id ); ?>" <?php echo in_array( $term->term_id, $target_ids, false ) ? 'selected' : ''; ?>>
                                    <?php echo esc_html( $term->name ); ?> (<?php echo esc_html( $term->count ); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>
                        <?php endif; endif; ?>

                    <?php else : /* pages */ ?>
                        <label><strong>Side/indlæg ID'er</strong></label>
                        <input type="text" name="ssm_rules[<?php echo esc_attr($i); ?>][target_ids][]"
                               value="<?php echo esc_attr( implode( ', ', $target_ids ) ); ?>"
                               placeholder="fx: 42, 87, 120" class="widefat ssm-ids-input">
                        <p class="description">
                            <a href="#" class="ssm-open-lookup">Søg efter sider/indlæg</a> for at finde ID'er.
                        </p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- JSON-LD editor -->
            <div class="ssm-rule-row">
                <div class="ssm-rule-col ssm-full">
                    <label>
                        <strong>JSON-LD Schema</strong>
                        <span class="ssm-schema-templates">
                            – hurtigt valg:
                            <a href="#" class="ssm-use-template" data-tpl="product_aggregate">Product + AggregateRating</a> |
                            <a href="#" class="ssm-use-template" data-tpl="local_business">LocalBusiness + AggregateRating</a> |
                            <a href="#" class="ssm-use-template" data-tpl="organization">Organization</a> |
                            <a href="#" class="ssm-use-template" data-tpl="faq">FAQPage</a>
                        </span>
                    </label>
                    <p class="description">Skriv kun JSON (uden <code>&lt;script&gt;</code>-tags) — disse tilføjes automatisk.</p>
                    <textarea
                        name="ssm_rules[<?php echo esc_attr($i); ?>][schema_json]"
                        class="ssm-code-editor ssm-schema-json widefat"
                        rows="14"
                        spellcheck="false"
                    ><?php echo esc_textarea( $schema_json ); ?></textarea>
                </div>
            </div>

            <!-- Validation -->
            <div class="ssm-validate-section">
                <div class="ssm-validate-header">
                    <strong><span class="dashicons dashicons-yes-alt"></span> Validér schema</strong>
                    <span class="ssm-validate-hint">Valgfrit: søg en side for at erstatte tokens med ægte data</span>
                </div>
                <div class="ssm-validate-controls">
                    <div class="ssm-validate-search-wrap">
                        <input type="text" class="ssm-validate-post-search widefat" placeholder="Søg side/indlæg for token-preview...">
                        <div class="ssm-validate-dropdown" style="display:none"></div>
                        <span class="ssm-validate-selected" style="display:none"></span>
                        <input type="hidden" class="ssm-validate-post-id" value="0">
                    </div>
                    <button type="button" class="button button-primary ssm-validate-btn">
                        <span class="dashicons dashicons-yes-alt"></span> Validér JSON
                    </button>
                </div>
                <div class="ssm-validate-result" style="display:none"></div>
            </div>

            <!-- Page lookup modal -->
            <div class="ssm-page-lookup-modal" style="display:none">
                <div class="ssm-lookup-inner">
                    <h4>Søg efter side eller indlæg</h4>
                    <input type="text" placeholder="Titel..." class="ssm-lookup-search widefat">
                    <div class="ssm-lookup-results"></div>
                    <button type="button" class="button ssm-lookup-close">Luk</button>
                </div>
            </div>
        </div>
    </div>
    <?php
}
