<?php
/**
 * Per-side meta box – indsæt script i <head> på en enkelt side/indlæg
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'add_meta_boxes', 'ssm_register_meta_boxes' );
function ssm_register_meta_boxes() {
    $post_types = get_post_types( [ 'public' => true ], 'names' );
    foreach ( $post_types as $pt ) {
        add_meta_box(
            'ssm_page_scripts',
            '<span class="dashicons dashicons-editor-code"></span> Script Manager – Side-specifikke Scripts',
            'ssm_page_scripts_meta_box',
            $pt,
            'normal',
            'default'
        );
    }
}

function ssm_page_scripts_meta_box( $post ) {
    wp_nonce_field( 'ssm_save_page_scripts', 'ssm_page_scripts_nonce' );
    $head_script = get_post_meta( $post->ID, '_ssm_head_script', true );
    ?>
    <div class="ssm-metabox-wrap">
        <div class="ssm-metabox-field">
            <label for="ssm_head_script">
                <span class="ssm-badge ssm-badge-head">&lt;head&gt;</span>
                Script til <code>&lt;head&gt;</code> <em>(kun denne side)</em>
            </label>
            <p class="description">Indsæt fx et side-specifikt JSON-LD schema, pixel eller andet script.</p>
            <textarea
                id="ssm_head_script"
                name="ssm_head_script"
                class="ssm-code-editor widefat"
                rows="10"
                spellcheck="false"
            ><?php echo esc_textarea( $head_script ); ?></textarea>
        </div>
    </div>
    <?php
}

add_action( 'save_post', 'ssm_save_page_scripts' );
function ssm_save_page_scripts( $post_id ) {
    if ( ! isset( $_POST['ssm_page_scripts_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['ssm_page_scripts_nonce'], 'ssm_save_page_scripts' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $head_script = isset( $_POST['ssm_head_script'] ) ? wp_unslash( $_POST['ssm_head_script'] ) : '';
    update_post_meta( $post_id, '_ssm_head_script', $head_script );
}
