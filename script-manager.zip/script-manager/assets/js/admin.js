/* Script & Schema Manager – Admin JS v1.1 */
(function($) {
    'use strict';

    var ruleIndex = $('.ssm-rule-card').length;

    /* Add new rule */
    $('#ssm-add-rule').on('click', function() {
        var tpl = $('#ssm-rule-template').html();
        tpl = tpl.replace(/__IDX__/g, ruleIndex);
        ruleIndex++;
        var $card = $(tpl);
        $card.addClass('ssm-new-card');
        $('#ssm-rules-empty').hide();
        $('#ssm-rules-container').append($card);
        $card[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
        $card.find('.ssm-rule-label-input').focus();
    });

    /* Remove unsaved rule */
    $(document).on('click', '.ssm-remove-rule', function() {
        if (!confirm('Fjern denne regel?')) return;
        $(this).closest('.ssm-rule-card').remove();
        if ($('.ssm-rule-card').length === 0) $('#ssm-rules-empty').show();
    });

    /* Target type toggle */
    $(document).on('change', '.ssm-target-type', function() {
        var $card = $(this).closest('.ssm-rule-card');
        var val   = $(this).val();
        var $wrap = $card.find('.ssm-target-ids-wrap');
        var idx   = $card.data('idx');
        var noIds = ['all','front_page','blog_index','search','not_found','date_archive','author_archive','any_archive'];
        if (noIds.indexOf(val) !== -1) {
            $wrap.hide();
        } else {
            $wrap.show();
            ssm_rebuild_ids_field($wrap, val, idx);
        }
    });

    function ssm_rebuild_ids_field($wrap, type, idx) {
        var html = '';
        if (type === 'post_type') {
            html = '<label><strong>Vælg post typer</strong></label>' +
                   '<select name="ssm_rules[' + idx + '][target_ids][]" class="ssm-ids-select widefat" multiple size="5">' +
                   ssmPostTypes.map(function(pt) { return '<option value="' + ssm_esc(pt.slug) + '">' + ssm_esc(pt.label) + ' (' + ssm_esc(pt.slug) + ')</option>'; }).join('') +
                   '</select><p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>';
        } else if (type === 'categories') {
            html = '<label><strong>Vælg kategorier</strong></label>' +
                   '<select name="ssm_rules[' + idx + '][target_ids][]" class="ssm-ids-select widefat" multiple size="5">' +
                   ssmCategories.map(function(c) { return '<option value="' + ssm_esc(c.id) + '">' + ssm_esc(c.name) + '</option>'; }).join('') +
                   '</select><p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>';
        } else if (type === 'tags') {
            html = '<label><strong>Vælg tags</strong></label>' +
                   '<select name="ssm_rules[' + idx + '][target_ids][]" class="ssm-ids-select widefat" multiple size="5">' +
                   ssmTags.map(function(t) { return '<option value="' + ssm_esc(t.id) + '">' + ssm_esc(t.name) + '</option>'; }).join('') +
                   '</select><p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>';
        } else if (type === 'custom_tax') {
            html = '<label><strong>Taxonomy</strong></label>' +
                   '<select name="ssm_rules[' + idx + '][custom_tax_slug]" class="ssm-custom-tax-select widefat">' +
                   '<option value="">— Vælg taxonomy —</option>' +
                   ssmCustomTaxonomies.map(function(tx) { return '<option value="' + ssm_esc(tx.slug) + '">' + ssm_esc(tx.label) + ' (' + ssm_esc(tx.slug) + ')</option>'; }).join('') +
                   '</select><div class="ssm-tax-terms-wrap" style="margin-top:10px"></div>';
        } else {
            html = '<label><strong>Side/indlæg ID\'er</strong></label>' +
                   '<input type="text" name="ssm_rules[' + idx + '][target_ids][]" placeholder="fx: 42, 87, 120" class="widefat ssm-ids-input">' +
                   '<p class="description"><a href="#" class="ssm-open-lookup">Søg efter sider/indlæg</a> for at finde ID\'er.</p>';
        }
        $wrap.html(html);
    }

    function ssm_esc(str) { return $('<div>').text(String(str)).html(); }

    /* Custom taxonomy: load terms */
    $(document).on('change', '.ssm-custom-tax-select', function() {
        var slug  = $(this).val();
        var $card = $(this).closest('.ssm-rule-card');
        var idx   = $card.data('idx');
        var $wrap = $(this).closest('.ssm-target-ids-wrap').find('.ssm-tax-terms-wrap');
        if (!slug) { $wrap.empty(); return; }
        $wrap.html('<p class="description">Indlæser terms...</p>');
        $.get(ssmData.ajaxurl, { action: 'ssm_get_tax_terms', nonce: ssmData.nonce, tax: slug, idx: idx }, function(resp) {
            if (!resp.success || !resp.data.length) { $wrap.html('<p class="description">Ingen terms fundet.</p>'); return; }
            $wrap.html(
                '<label><strong>Vælg terms</strong> <small>(valgfrit — tom = alle)</small></label>' +
                '<select name="ssm_rules[' + idx + '][target_ids][]" class="ssm-ids-select widefat" multiple size="5">' +
                resp.data.map(function(t) { return '<option value="' + t.id + '">' + ssm_esc(t.name) + ' (' + t.count + ')</option>'; }).join('') +
                '</select><p class="description">Hold Ctrl/Cmd nede for at vælge flere.</p>'
            );
        });
    });

    /* Schema templates */
    $(document).on('click', '.ssm-use-template', function(e) {
        e.preventDefault();
        var tpl = $(this).data('tpl');
        if (!ssmTemplates[tpl]) return;
        var $textarea = $(this).closest('.ssm-rule-col').find('.ssm-schema-json');
        if ($textarea.val().trim() !== '' && !confirm('Erstat det nuværende schema med denne skabelon?')) return;
        $textarea.val(ssmTemplates[tpl]);
    });

    /* Token copy */
    $(document).on('click', '.ssm-token-copy', function() {
        var token = $(this).text();
        navigator.clipboard.writeText(token);
        var $el = $(this), orig = $el.text();
        $el.text('✓ Kopieret!').css('background', '#d1fae5');
        setTimeout(function() { $el.text(orig).css('background', ''); }, 1500);
    });

    /* Validation: post search with inline dropdown */
    var vTimer = null;
    $(document).on('input', '.ssm-validate-post-search', function() {
        var q       = $(this).val().trim();
        var $input  = $(this);
        var $drop   = $input.siblings('.ssm-validate-dropdown');
        var $hidden = $input.siblings('.ssm-validate-post-id');
        var $sel    = $input.siblings('.ssm-validate-selected');

        // Reset selection when typing
        $hidden.val('0');
        $sel.hide();

        clearTimeout(vTimer);
        if (q.length < 2) { $drop.hide().empty(); return; }

        $drop.html('<div class="ssm-vdrop-item ssm-vdrop-loading">Søger...</div>').show();

        vTimer = setTimeout(function() {
            $.get(ssmData.ajaxurl, { action: 'ssm_search_posts', nonce: ssmData.nonce, q: q }, function(resp) {
                $drop.empty();
                if (!resp.success || !resp.data.length) {
                    $drop.html('<div class="ssm-vdrop-item ssm-vdrop-empty">Ingen resultater</div>').show();
                    return;
                }
                $.each(resp.data, function(i, item) {
                    $('<div class="ssm-vdrop-item">')
                        .html('<strong>' + ssm_esc(item.title) + '</strong> <span class="ssm-vdrop-type">' + item.type + ' #' + item.id + '</span>')
                        .data('id', item.id)
                        .data('title', item.title)
                        .appendTo($drop);
                });
                $drop.show();
            });
        }, 350);
    });

    /* Click result in dropdown */
    $(document).on('click', '.ssm-vdrop-item', function() {
        if ($(this).hasClass('ssm-vdrop-loading') || $(this).hasClass('ssm-vdrop-empty')) return;
        var id    = $(this).data('id');
        var title = $(this).data('title');
        var $wrap = $(this).closest('.ssm-validate-search-wrap');
        $wrap.find('.ssm-validate-post-id').val(id);
        $wrap.find('.ssm-validate-post-search').val('');
        $wrap.find('.ssm-validate-selected').html('✓ <strong>' + ssm_esc(title) + '</strong> (#' + id + ') <a href="#" class="ssm-validate-clear">×</a>').show();
        $wrap.find('.ssm-validate-dropdown').hide().empty();
    });

    /* Clear selected post */
    $(document).on('click', '.ssm-validate-clear', function(e) {
        e.preventDefault();
        var $wrap = $(this).closest('.ssm-validate-search-wrap');
        $wrap.find('.ssm-validate-post-id').val('0');
        $wrap.find('.ssm-validate-selected').hide().empty();
        $wrap.find('.ssm-validate-post-search').val('').focus();
    });

    /* Close dropdown on outside click */
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.ssm-validate-search-wrap').length) {
            $('.ssm-validate-dropdown').hide();
        }
    });

    /* Validation: run */
    $(document).on('click', '.ssm-validate-btn', function() {
        var $section = $(this).closest('.ssm-validate-section');
        var $card    = $(this).closest('.ssm-rule-card');
        var $result  = $section.find('.ssm-validate-result');
        var json     = $card.find('.ssm-schema-json').val();
        var postId   = parseInt( $section.find('.ssm-validate-post-id').val() ) || 0;
        var $btn     = $(this);

        $result.hide().removeClass('ssm-validate-ok ssm-validate-err');
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update ssm-spin"></span> Validerer...');

        $.post(ssmData.ajaxurl, { action: 'ssm_validate_schema', nonce: ssmData.nonce, schema_json: json, post_id: postId }, function(resp) {
            $btn.prop('disabled', false).html('<span class="dashicons dashicons-yes-alt"></span> Validér JSON');
            if (resp.success) {
                var d = resp.data;

                var schemaOrgJson = '<script type="application/ld+json">\n' + d.json + '\n<\/script>';

                // schema.org validator: POST to new window via a temporary form appended to body
                var schemaOrgBtn = '<button type="button" class="button button-small ssm-schemaorg-btn" data-json="' + ssm_attr_esc(schemaOrgJson) + '">🔬 Test på schema.org</button>';

                var googleLink = d.test_url
                    ? '<a href="' + d.test_url + '" target="_blank" class="button button-small">🔍 Google Rich Results Test</a>'
                    : '';

                var pageLink = d.post_url
                    ? '<a href="' + d.post_url + '" target="_blank" class="button button-small">↗ Vis side</a>'
                    : '';

                var tokenNote = postId
                    ? '<p class="ssm-validate-token-note">✓ Tokens erstattet med data fra side #' + postId + '</p>'
                    : '<p class="ssm-validate-token-note ssm-token-warning">⚠ Ingen side valgt — tokens er <strong>ikke</strong> erstattet. Søg en side ovenfor for at se reelle værdier.</p>';

                $result.addClass('ssm-validate-ok').html(
                    '<h4><span class="dashicons dashicons-yes-alt" style="color:#15803d"></span> Gyldig JSON-LD</h4>' +
                    tokenNote +
                    '<div class="ssm-validate-json">' + ssm_esc(d.json) + '</div>' +
                    '<div class="ssm-validate-links">' + schemaOrgBtn + ' ' + googleLink + ' ' + pageLink + '</div>'
                ).show();
            } else {
                $result.addClass('ssm-validate-err').html(
                    '<h4><span class="dashicons dashicons-warning"></span> Ugyldig JSON</h4>' +
                    '<p style="margin:0;font-size:13px">' + ssm_esc(resp.data.message) + '</p>'
                ).show();
            }
        });
    });

    /* schema.org validator - POST in new window, outside WP admin form */
    $(document).on('click', '.ssm-schemaorg-btn', function() {
        var json = $(this).data('json');
        var $form = $('<form method="post" action="https://validator.schema.org/" target="_blank" style="display:none">' +
            '<input type="hidden" name="code">' +
            '</form>');
        $form.find('input[name="code"]').val(json);
        $('body').append($form);
        $form[0].submit();
        $form.remove();
    });

    function ssm_attr_esc(str) {
        return str.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    /* Page lookup modal */
    $(document).on('click', '.ssm-open-lookup', function(e) {
        e.preventDefault();
        var $card = $(this).closest('.ssm-rule-card');
        var $modal = $card.find('.ssm-page-lookup-modal');
        $modal.show();
        $modal.find('.ssm-lookup-search').val('').focus();
        $modal.find('.ssm-lookup-results').empty();
    });
    $(document).on('click', '.ssm-lookup-close', function() { $(this).closest('.ssm-page-lookup-modal').hide(); });
    $(document).on('click', '.ssm-page-lookup-modal', function(e) { if ($(e.target).hasClass('ssm-page-lookup-modal')) $(this).hide(); });

    $(document).on('input', '.ssm-lookup-search', function() {
        var q = $(this).val(), $modal = $(this).closest('.ssm-page-lookup-modal');
        if (q.length < 2) { $modal.find('.ssm-lookup-results').html('<p style="color:#999;font-size:13px;">Skriv mindst 2 tegn...</p>'); return; }
        $.get(ssmData.ajaxurl, { action: 'ssm_search_posts', nonce: ssmData.nonce, q: q }, function(resp) {
            if (!resp.success || !resp.data.length) { $modal.find('.ssm-lookup-results').html('<p style="color:#999;font-size:13px;">Ingen resultater.</p>'); return; }
            $modal.find('.ssm-lookup-results').html(resp.data.map(function(item) {
                return '<div class="ssm-lookup-result-item"><span><strong>' + ssm_esc(item.title) + '</strong> <small style="color:#888">(' + item.type + ' #' + item.id + ')</small></span><a class="ssm-lookup-add-id" data-id="' + item.id + '">Tilføj ID</a></div>';
            }).join(''));
        });
    });

    $(document).on('click', '.ssm-lookup-add-id', function() {
        var id = $(this).data('id');
        var $input = $(this).closest('.ssm-rule-card').find('.ssm-ids-input');
        var ids = $input.val().trim() ? $input.val().split(',').map(function(s) { return s.trim(); }) : [];
        if (ids.indexOf(String(id)) === -1) { ids.push(id); $input.val(ids.join(', ')); }
        var $btn = $(this);
        $btn.text('✓ Tilføjet').css('color', '#0a7c3a');
        setTimeout(function() { $btn.text('Tilføj ID').css('color', ''); }, 1500);
    });

})(jQuery);
