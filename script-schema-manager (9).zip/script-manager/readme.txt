=== Script & Schema Manager ===
Contributors: emrekandemir
Plugin URI: https://organicgrowth.dk
Tags: schema, json-ld, structured data, header scripts, seo
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Insert header/body/footer scripts and dynamic JSON-LD schema (Product, AggregateRating, LocalBusiness) on selected pages, post types or taxonomies.

== Description ==

**Script & Schema Manager** gives you full control over scripts and structured data on your WordPress site — without editing theme files.

= Global Scripts =
Insert scripts into `<head>`, `<body>` (after opening tag), and `</body>` (footer) across your entire site. Perfect for Google Tag Manager, analytics, chat widgets and more.

= Per-Page Head Scripts =
Each post and page gets a dedicated script field in the editor. Insert page-specific JSON-LD, pixels or any other `<head>` script directly from the post edit screen.

= Dynamic Schema Markup =
Create rules that automatically insert JSON-LD schema on exactly the pages you choose. Use dynamic tokens that pull real data from each page:

* `{post_title}` — Page title
* `{featured_image_url}` — Featured image URL
* `{post_excerpt}` — Excerpt / description
* `{permalink}` — Full page URL
* `{site_name}`, `{logo_url}`, `{site_url}` — Site-level data
* `{cf_fieldname}` — Any custom field or ACF field (e.g. `{cf_price}`, `{cf_city}`)

= Target Rules By =
* Specific pages/posts (ID search)
* Post type (all posts of a type)
* Categories, tags, or any custom taxonomy
* Conditional: front page, 404, search results, date/author archives

= Built-in Schema Templates =
* Product + AggregateRating
* LocalBusiness + AggregateRating
* Organization
* FAQPage

= BreadcrumbList Schema =
Automatically generate BreadcrumbList JSON-LD on all pages. Integrates with Yoast SEO breadcrumbs if available.

= Schema Validation =
Validate your JSON-LD directly in the admin:
* See tokens replaced with real data from any page
* Send directly to **schema.org validator** in one click
* Link to **Google Rich Results Test**

= ACF Support =
Custom field tokens work seamlessly with Advanced Custom Fields — image fields return the URL, relationship fields return the title.

== Installation ==

1. Upload the `script-manager` folder to `/wp-content/plugins/`
2. Activate the plugin in **Plugins → Installed Plugins**
3. Go to **Script Manager** in the admin menu

== Frequently Asked Questions ==

= Does this conflict with Yoast SEO schema? =
No. The plugin outputs its own `<script type="application/ld+json">` blocks independently. If you use Yoast, disable Yoast's schema for the specific post types you manage here to avoid duplicates.

= Who can add scripts? =
Global scripts and schema rules require `manage_options` (Administrator). Per-page scripts additionally require `unfiltered_html`, which protects multisite installations.

= Does it work with ACF image fields? =
Yes. ACF image fields configured to return "Image Array" are handled automatically — the URL is extracted. Gallery fields return the first image URL.

= Can I use it for AggregateRating on many pages at once? =
Yes — that is the primary use case. Set `ratingValue` and `ratingCount` once in the rule, target a post type or category, and all matching pages get the schema automatically. Update the rating in one place and it propagates everywhere.

== Screenshots ==

1. Global Scripts settings — Header, Body and Footer fields
2. Schema Rules — dynamic JSON-LD with token reference
3. Validation panel — live token preview and schema.org test button
4. Per-page Head Script field in the post editor

== Changelog ==

= 1.1.0 =
* Added: Custom taxonomy targeting
* Added: Extended conditional logic (front page, 404, search, archives, author)
* Added: BreadcrumbList schema auto-generator with Yoast integration
* Added: Schema validation panel with schema.org and Google Rich Results Test
* Added: Custom field / ACF token support (`{cf_fieldname}`)
* Added: Tags as a targeting option
* Fixed: Double `<script>` tag when JSON contained script tags
* Fixed: Post type dropdown replaces text input
* Security: Added `unfiltered_html` check for script saving
* Security: Replaced `wp_redirect` with `wp_safe_redirect`
* Security: Added `wp_cache_get/set` for database queries
* Security: All `$_POST`/`$_GET` inputs properly unslashed

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.1.0 =
Major feature update. Custom field tokens, validation panel, extended targeting conditions and several security improvements.
